#!/bin/sh
printf 'Status: 302 Found\r\n'
printf 'Location: http://192.168.88.1/\r\n'
printf 'Cache-Control: no-cache\r\n'
printf 'Content-Type: text/html; charset=utf-8\r\n'
printf '\r\n'
printf '<a href="http://192.168.88.1/">金维组网初始化</a>\n'
